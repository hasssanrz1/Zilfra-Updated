import React from "react";
import "./App.css";
import { Homepage } from "./containers/homepage";

function App(props) {
  return <Homepage />;
}

export default App;
