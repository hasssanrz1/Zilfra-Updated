export const theme = {
  primary: "#00B997",
};
