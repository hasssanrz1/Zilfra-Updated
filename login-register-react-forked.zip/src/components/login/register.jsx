import React from "react";
import loginImg from "../../login.svg";

export class Register extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="base-container"  ref={this.props.containerRef } 
      >
        <div className="header" ></div>
        <div className="content">
          <div className="image">
            <img src={loginImg} />
          </div>
          <div className="form">
            <div className="form-group">
              <label htmlFor="username">Username</label>
              <input type="text" name="username" placeholder="username" />
            </div>
          
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input type="text" name="password" placeholder="password" />
            </div>
            <div className="form-group">
              <label htmlFor="CNIC">CNIC</label>
              <input type="text" name="CNIC" placeholder="CNIC" maxLength="13" />
            </div>
            <div className="form-group">
              <label htmlFor="ep account">Easy Paisa Account</label>
              <input type="text" name="ep account" placeholder="Easy Paisa Account" maxLength="11"/>
            </div>     
          </div>
        </div>
        <div className="footer">
          <button type="button" className="btn">
            Register
          </button>
        </div>
      </div>
    );
  }
}
