import React from "react";
import LoanForm from "./LoanForm";
import Collapse1 from "../Collapse1/Collapse1";
import LoanCases from "./LoanCases";
const Loan = () => {
return(
  <>
  <LoanForm/>
  <LoanCases/>
</>
);
}
export default Loan;