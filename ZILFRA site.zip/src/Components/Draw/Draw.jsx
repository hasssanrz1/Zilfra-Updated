import React from "react";
import DCases from "./DCases";
const Draw = () => {
return(
  <>
<DCases/>
</>
);
}
export default Draw;