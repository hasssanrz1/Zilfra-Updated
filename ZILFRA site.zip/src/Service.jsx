import React from "react";

const Service = () => {

return(
  <>
<h1> Welcomp to Service page </h1>
</>
);
}
export default Service;